<?php
$site_title = "Karşılaştırma | İşrâkiyye";
require __DIR__ . "/includes/header.php";
?>

<section class="text-center py-10">
    <p class="uppercase tracking-[0.3em] text-xs text-nur-gold mb-3">Mukayeseli Tasnif</p>
    <h1 class="font-display text-3xl md:text-4xl text-nur-gold text-glow mb-4">
        İşrâkilik, Meşşâîlik ve Tasavvuf
    </h1>
    <p class="max-w-2xl mx-auto text-gray-400">
        Üç geleneğin bilgi kaynağı, varlık anlayışı ve hedefi bakımından
        karşılaştırmalı bir okuması.
    </p>
</section>

<div class="nur-divider my-8"></div>

<section class="overflow-x-auto mb-14">
    <table class="w-full text-left border-collapse text-sm">
        <thead>
            <tr class="text-nur-gold border-b nur-border">
                <th class="py-4 px-4 font-display">Ölçüt</th>
                <th class="py-4 px-4 font-display">İşrâkilik</th>
                <th class="py-4 px-4 font-display">Meşşâîlik</th>
                <th class="py-4 px-4 font-display">Tasavvuf</th>
            </tr>
        </thead>
        <tbody class="text-gray-300">
            <tr class="border-b nur-border/60">
                <td class="py-4 px-4 font-semibold text-nur-amber">Temel Bilgi Kaynağı</td>
                <td class="py-4 px-4">Huzûrî ilim (zevk/keşif) + akli burhan</td>
                <td class="py-4 px-4">Akli istidlal, mantıksal burhan, tanım (hadd)</td>
                <td class="py-4 px-4">Keşf, ilham, manevi hâl ve zevk</td>
            </tr>
            <tr class="border-b nur-border/60">
                <td class="py-4 px-4 font-semibold text-nur-amber">Varlık Anlayışı</td>
                <td class="py-4 px-4">Varlık = nûr yoğunluğu; hiyerarşik ışık-karanlık tasnifi</td>
                <td class="py-4 px-4">Varlık = vücûd/mahiyet ayrımı; vacip-mümkün hiyerarşisi</td>
                <td class="py-4 px-4">Vahdet-i vücûd veya vahdet-i şuhûd; Hak'tan gayrı yokluk</td>
            </tr>
            <tr class="border-b nur-border/60">
                <td class="py-4 px-4 font-semibold text-nur-amber">Yöntem</td>
                <td class="py-4 px-4">Riyazet + mantıksal çerçeve; sembolik anlatım</td>
                <td class="py-4 px-4">Sistemli mantık, tanım ve kıyas (burhan)</td>
                <td class="py-4 px-4">Seyr u sülûk, zikir, mürşid rehberliği</td>
            </tr>
            <tr class="border-b nur-border/60">
                <td class="py-4 px-4 font-semibold text-nur-amber">Öncü / Temsilci</td>
                <td class="py-4 px-4">Şihâbüddîn Sühreverdî</td>
                <td class="py-4 px-4">Fârâbî, İbn Sînâ</td>
                <td class="py-4 px-4">Muhyiddin İbnü'l-Arabî, Mevlânâ, Gazzâlî (geç dönem)</td>
            </tr>
            <tr class="border-b nur-border/60">
                <td class="py-4 px-4 font-semibold text-nur-amber">Anlatım Dili</td>
                <td class="py-4 px-4">Felsefi + sembolik/alegorik (Kırmızı Akıl vb.)</td>
                <td class="py-4 px-4">Teknik, sistematik, mantık terminolojisi ağırlıklı</td>
                <td class="py-4 px-4">Şiirsel, aşk ve istiare dili</td>
            </tr>
            <tr>
                <td class="py-4 px-4 font-semibold text-nur-amber">Nihai Gaye</td>
                <td class="py-4 px-4">Nefsin nûrânî aslına dönüşü; hikmet ile aydınlanma</td>
                <td class="py-4 px-4">Akli kemal; Vacibü'l-Vücûd'u burhanla bilme</td>
                <td class="py-4 px-4">Fenâ, Hakk'a vuslat, manevi kemal</td>
            </tr>
        </tbody>
    </table>
</section>

<div class="nur-divider my-10"></div>

<section class="grid md:grid-cols-3 gap-6 mb-10">
    <div class="nur-card rounded-xl p-6">
        <h3 class="font-display text-nur-amber mb-3">İşrâkilik</h3>
        <p class="text-sm text-gray-300 leading-relaxed">
            Akıl ile zevki, burhan ile keşfi aynı potada eritmeye çalışan köprü bir
            gelenektir. Ne salt rasyonalisttir, ne de yalnızca mistik; ikisinin
            sentezini "nûr" kavramı etrafında kurar.
        </p>
    </div>
    <div class="nur-card rounded-xl p-6">
        <h3 class="font-display text-nur-amber mb-3">Meşşâîlik</h3>
        <p class="text-sm text-gray-300 leading-relaxed">
            Aristoteles mantığının ve metafiziğinin İslam düşüncesine uyarlanmış
            hâlidir. Bilgiye sistemli tanım, kıyas ve burhan yoluyla ulaşmayı esas alır;
            Sühreverdî'nin en çok eleştirdiği gelenektir.
        </p>
    </div>
    <div class="nur-card rounded-xl p-6">
        <h3 class="font-display text-nur-amber mb-3">Tasavvuf</h3>
        <p class="text-sm text-gray-300 leading-relaxed">
            Bilgiyi büyük ölçüde manevi hâl, zikir ve mürşid rehberliğiyle elde eden,
            dili aşk ve istiareyle örülü bir yoldur. İşrâkiyye, tasavvufun zevk
            anlayışını felsefi bir çerçeveyle temellendirmeye çalışır.
        </p>
    </div>
</section>

<?php require __DIR__ . "/includes/footer.php"; ?>
