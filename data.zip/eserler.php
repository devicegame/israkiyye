<?php
$site_title = "Eserler ve Risaleler | İşrâkiyye";
require __DIR__ . "/includes/header.php";
require __DIR__ . "/data/content.php";
?>

<section class="text-center py-10">
    <p class="uppercase tracking-[0.3em] text-xs text-nur-gold mb-3">Külliyat</p>
    <h1 class="font-display text-3xl md:text-4xl text-nur-gold text-glow mb-4">Eserler ve Sembolik Risaleler</h1>
    <p class="max-w-2xl mx-auto text-gray-400">
        Hikmetü'l-İşrâk'tan sembolik hikâyelere, Sühreverdî'nin hem akli hem de
        edebi-mistik üretimine topluca bir bakış.
    </p>
</section>

<div class="nur-divider my-8"></div>

<section class="space-y-10">
    <?php foreach ($eserler as $e): ?>
        <article id="<?php echo $e['slug']; ?>" class="nur-card rounded-2xl p-8 scroll-mt-24">
            <p class="text-xs uppercase tracking-widest text-nur-gold mb-2"><?php echo $e["tur"]; ?></p>
            <h2 class="font-display text-2xl text-nur-amber mb-3"><?php echo $e["baslik"]; ?></h2>
            <p class="text-sm text-gray-400 italic mb-4"><?php echo $e["ozet"]; ?></p>
            <div class="nur-divider mb-4"></div>
            <p class="text-gray-300 leading-relaxed"><?php echo $e["detay"]; ?></p>
        </article>
    <?php endforeach; ?>
</section>

<?php require __DIR__ . "/includes/footer.php"; ?>
