<?php
require_once __DIR__ . '/includes/media_lib.php';

$user = require_user();
$uid  = (int)$user['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check()) {
        flash_set('err', 'Güvenlik doğrulaması başarısız. Tekrar deneyin.');
        redirect('dashboard.php');
    }
    $action = $_POST['action'] ?? '';

    /* ---- Yeni post ---- */
    if ($action === 'create_post') {
        $title   = trim((string)($_POST['title'] ?? ''));
        $content = trim((string)($_POST['content'] ?? ''));
        $err = null;

        if (str_len($title) < 2 || str_len($title) > 120) {
            $err = 'Başlık 2-120 karakter arasında olmalı.';
        } elseif (str_len($content) < 1 || str_len($content) > 5000) {
            $err = 'Açıklama metni 1-5000 karakter arasında olmalı.';
        }

        $image = null;
        if ($err === null) {
            $image = handle_image_upload($_FILES['image'] ?? ['error' => UPLOAD_ERR_NO_FILE], $upErr);
            if ($upErr) {
                $err = $upErr;
            }
        }

        if ($err !== null) {
            flash_set('err', $err);
        } else {
            json_update(POSTS_FILE, function (&$posts) use ($uid, $title, $content, $image) {
                $posts[] = [
                    'id'         => next_id($posts),
                    'user_id'    => $uid,
                    'title'      => $title,
                    'content'    => $content,
                    'image_url'  => $image ?: '',
                    'created_at' => date('Y-m-d H:i:s'),
                ];
            });
            flash_set('ok', 'Post yayınlandı.');
        }
        redirect('dashboard.php');
    }

    /* ---- Post sil (yalnızca kendi postu) ---- */
    if ($action === 'delete_post') {
        $pid = (int)($_POST['id'] ?? 0);
        $deleted = json_update(POSTS_FILE, function (&$posts) use ($pid, $uid) {
            $found = false;
            $posts = array_values(array_filter($posts, function ($p) use ($pid, $uid, &$found) {
                if ((int)$p['id'] === $pid && (int)$p['user_id'] === $uid) {
                    delete_upload($p['image_url'] ?? '');
                    $found = true;
                    return false;
                }
                return true;
            }));
            return $found;
        });
        flash_set($deleted ? 'ok' : 'err', $deleted ? 'Post silindi.' : 'Post bulunamadı.');
        redirect('dashboard.php');
    }

    /* ---- Profil güncelle ---- */
    if ($action === 'update_profile') {
        $channel = trim((string)($_POST['channel_name'] ?? ''));
        $bio     = trim((string)($_POST['bio'] ?? ''));
        $err = null;

        if (str_len($channel) < 2 || str_len($channel) > 60) {
            $err = 'Kanal adı 2-60 karakter arasında olmalı.';
        } elseif (str_len($bio) > 280) {
            $err = 'Kısa açıklama en fazla 280 karakter olabilir.';
        }

        $avatar = null;
        if ($err === null) {
            $avatar = handle_image_upload($_FILES['avatar'] ?? ['error' => UPLOAD_ERR_NO_FILE], $upErr);
            if ($upErr) {
                $err = 'Avatar: ' . $upErr;
            }
        }

        if ($err !== null) {
            flash_set('err', $err);
        } else {
            $oldAvatar = json_update(USERS_FILE, function (&$users) use ($uid, $channel, $bio, $avatar) {
                $old = null;
                foreach ($users as &$u) {
                    if ((int)$u['id'] === $uid) {
                        $u['channel_name'] = $channel;
                        $u['bio'] = $bio;
                        if ($avatar) {
                            $old = $u['avatar_url'] ?? '';
                            $u['avatar_url'] = $avatar;
                        }
                    }
                }
                unset($u);
                return $old;
            });
            if ($avatar) {
                delete_upload($oldAvatar);
            }
            flash_set('ok', 'Profil güncellendi.');
        }
        redirect('dashboard.php');
    }

    /* ---- Şifre değiştir ---- */
    if ($action === 'change_password') {
        $cur = (string)($_POST['current'] ?? '');
        $new = (string)($_POST['new'] ?? '');
        if (!password_verify($cur, $user['password_hash'])) {
            flash_set('err', 'Mevcut şifre hatalı.');
        } elseif (strlen($new) < 8) {
            flash_set('err', 'Yeni şifre en az 8 karakter olmalı.');
        } else {
            $hash = password_hash($new, PASSWORD_DEFAULT);
            json_update(USERS_FILE, function (&$users) use ($uid, $hash) {
                foreach ($users as &$u) {
                    if ((int)$u['id'] === $uid) {
                        $u['password_hash'] = $hash;
                    }
                }
                unset($u);
            });
            flash_set('ok', 'Şifre güncellendi.');
        }
        redirect('dashboard.php');
    }

    redirect('dashboard.php');
}

$posts = posts_of_user($uid);
$site_title = "Panel | " . $user['channel_name'];
require __DIR__ . '/includes/header.php';
$inputCls = 'w-full px-4 py-2.5 rounded-lg bg-white/5 border nur-border text-gray-200 focus:outline-none focus:border-nur-gold';
?>

<section class="py-6">
    <div class="flex items-center justify-between gap-4 mb-8 flex-wrap">
        <div class="flex items-center gap-4">
            <?php echo avatar_html($user); ?>
            <div>
                <p class="uppercase tracking-[0.3em] text-xs text-nur-gold">Kanal Paneli</p>
                <h1 class="font-display text-2xl text-nur-gold text-glow"><?php echo e($user['channel_name']); ?></h1>
            </div>
        </div>
        <div class="flex items-center gap-5 text-sm">
            <a href="medya-detay.php?id=<?php echo $uid; ?>" class="text-nur-amber hover:underline">Kanalımı Gör</a>
            <form method="post" action="logout.php">
                <?php echo csrf_field(); ?>
                <button class="text-gray-400 hover:text-nur-gold transition">Çıkış Yap</button>
            </form>
        </div>
    </div>

    <?php flash_render(); ?>

    <!-- Yeni post -->
    <div class="nur-card rounded-2xl p-6 mb-10">
        <h2 class="font-display text-xl text-nur-amber mb-4">Yeni Post Paylaş</h2>
        <form method="post" enctype="multipart/form-data" class="space-y-3">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="action" value="create_post">
            <input class="<?php echo $inputCls; ?>" name="title" placeholder="Başlık" required maxlength="120">
            <textarea class="<?php echo $inputCls; ?>" name="content" rows="6" placeholder="Açıklama metni" required maxlength="5000"></textarea>
            <label class="block text-sm text-gray-400">Görsel (isteğe bağlı, JPG/PNG/GIF/WEBP, en fazla 3 MB)
                <input type="file" name="image" accept="image/jpeg,image/png,image/gif,image/webp" class="mt-1 block w-full text-sm text-gray-400">
            </label>
            <button class="px-6 py-2.5 bg-nur-gold text-nur-bg font-semibold rounded-full hover:bg-nur-amber transition">Paylaş</button>
        </form>
    </div>

    <!-- Postlarım -->
    <h2 class="font-display text-xl text-nur-amber mb-5">Postlarım (<?php echo count($posts); ?>)</h2>
    <?php if (!$posts): ?>
        <p class="text-gray-500 mb-10">Henüz post paylaşmadınız.</p>
    <?php else: ?>
        <div class="space-y-3 mb-12">
        <?php foreach ($posts as $p): ?>
            <div class="nur-card rounded-xl p-4 flex items-center gap-4">
                <?php if (!empty($p['image_url'])): ?>
                    <img src="<?php echo e($p['image_url']); ?>" alt="" class="w-16 h-16 object-cover rounded-lg border nur-border">
                <?php endif; ?>
                <div class="flex-1 min-w-0">
                    <p class="text-nur-amber truncate"><?php echo e($p['title']); ?></p>
                    <p class="text-xs text-gray-500"><?php echo e(fmt_date($p['created_at'])); ?></p>
                </div>
                <form method="post" onsubmit="return confirm('Bu post silinsin mi?');">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="action" value="delete_post">
                    <input type="hidden" name="id" value="<?php echo (int)$p['id']; ?>">
                    <button class="text-xs text-red-400 hover:text-red-300 transition">Sil</button>
                </form>
            </div>
        <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <div class="nur-divider my-10"></div>

    <div class="grid md:grid-cols-2 gap-8">
        <!-- Profil -->
        <div class="nur-card rounded-2xl p-6">
            <h2 class="font-display text-xl text-nur-amber mb-4">Profili Düzenle</h2>
            <form method="post" enctype="multipart/form-data" class="space-y-3">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="update_profile">
                <input class="<?php echo $inputCls; ?>" name="channel_name" value="<?php echo e($user['channel_name']); ?>" required maxlength="60">
                <textarea class="<?php echo $inputCls; ?>" name="bio" rows="3" maxlength="280" placeholder="Kısa açıklama"><?php echo e($user['bio']); ?></textarea>
                <label class="block text-sm text-gray-400">Yeni avatar (isteğe bağlı)
                    <input type="file" name="avatar" accept="image/jpeg,image/png,image/gif,image/webp" class="mt-1 block w-full text-sm text-gray-400">
                </label>
                <button class="px-6 py-2.5 border nur-border text-nur-gold rounded-full hover:bg-white/5 transition">Kaydet</button>
            </form>
        </div>

        <!-- Şifre -->
        <div class="nur-card rounded-2xl p-6 self-start">
            <h2 class="font-display text-xl text-nur-amber mb-4">Şifre Değiştir</h2>
            <form method="post" class="space-y-3">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="change_password">
                <input class="<?php echo $inputCls; ?>" type="password" name="current" placeholder="Mevcut şifre" required autocomplete="current-password">
                <input class="<?php echo $inputCls; ?>" type="password" name="new" placeholder="Yeni şifre (en az 8 karakter)" required autocomplete="new-password">
                <button class="px-6 py-2.5 border nur-border text-nur-gold rounded-full hover:bg-white/5 transition">Güncelle</button>
            </form>
        </div>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
