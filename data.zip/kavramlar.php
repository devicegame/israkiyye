<?php
$site_title = "Kavramlar | İşrâkiyye";
require __DIR__ . "/includes/header.php";
require __DIR__ . "/data/content.php";
?>

<section class="text-center py-10">
    <p class="uppercase tracking-[0.3em] text-xs text-nur-gold mb-3">Sözlük</p>
    <h1 class="font-display text-3xl md:text-4xl text-nur-gold text-glow mb-4">İşrâkî Kavramlar</h1>
    <p class="max-w-2xl mx-auto text-gray-400">
        Sühreverdî'nin nûr metafiziğini ve epistemolojisini kuran temel kavramlar,
        veritabanı kullanılmadan doğrudan PHP dizisi üzerinden listelenmiştir.
    </p>
</section>

<div class="nur-divider my-8"></div>

<section class="space-y-10">
    <?php foreach ($kavramlar as $k): ?>
        <article id="<?php echo $k['slug']; ?>" class="nur-card rounded-2xl p-8 scroll-mt-24">
            <h2 class="font-display text-2xl text-nur-amber mb-2"><?php echo $k["baslik"]; ?></h2>
            <p class="text-nur-gold text-sm italic mb-4"><?php echo $k["kisa"]; ?></p>
            <p class="text-gray-300 leading-relaxed"><?php echo $k["detay"]; ?></p>
        </article>
    <?php endforeach; ?>
</section>

<?php require __DIR__ . "/includes/footer.php"; ?>
