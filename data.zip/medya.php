<?php
$site_title = "Medya | İşrâkiyye";
require_once __DIR__ . '/includes/media_lib.php';
require __DIR__ . '/includes/header.php';

$users = get_users();
$counts = [];
foreach (get_posts() as $p) {
    $counts[(int)$p['user_id']] = ($counts[(int)$p['user_id']] ?? 0) + 1;
}
?>

<section class="text-center py-10">
    <p class="uppercase tracking-[0.3em] text-xs text-nur-gold mb-3">Kanallar</p>
    <h1 class="font-display text-3xl md:text-4xl text-nur-gold text-glow mb-4">Medya</h1>
    <p class="max-w-2xl mx-auto text-gray-400">
        İşrâkî hikmet çevresinde içerik üreten medya hesapları ve kanalları.
    </p>
</section>

<div class="nur-divider my-8"></div>

<?php if (!$users): ?>
    <p class="text-center text-gray-500 py-10">Henüz yayında bir medya kanalı yok.</p>
<?php else: ?>
    <section class="grid sm:grid-cols-2 md:grid-cols-3 gap-6">
        <?php foreach ($users as $u): ?>
            <a href="medya-detay.php?id=<?php echo (int)$u['id']; ?>"
               class="nur-card rounded-2xl p-6 text-center hover:border-nur-gold/60 transition block">
                <div class="flex justify-center mb-4">
                    <?php echo avatar_html($u, 'w-20 h-20', 'text-3xl'); ?>
                </div>
                <h2 class="font-display text-lg text-nur-amber mb-2"><?php echo e($u['channel_name']); ?></h2>
                <?php if (!empty($u['bio'])): ?>
                    <p class="text-sm text-gray-400 leading-relaxed"><?php echo e($u['bio']); ?></p>
                <?php endif; ?>
                <p class="text-xs text-nur-gold mt-4"><?php echo (int)($counts[(int)$u['id']] ?? 0); ?> post &rarr;</p>
            </a>
        <?php endforeach; ?>
    </section>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>
