<?php
$current = basename($_SERVER['PHP_SELF']);
function nav_active($page, $current) {
    return $page === $current ? "text-nur-gold border-b border-nur-gold" : "text-gray-300 hover:text-nur-gold transition";
}
?>
<header class="sticky top-0 z-50 backdrop-blur-md bg-nur-bg/80 border-b nur-border">
    <div class="max-w-5xl mx-auto px-5 md:px-8 py-4 flex items-center justify-between">
        <a href="index.php" class="font-display text-xl tracking-widest text-nur-gold text-glow">
            إشراق <span class="text-sm text-gray-400 font-serif tracking-normal">İşrâkiyye</span>
        </a>

        <nav class="hidden md:flex items-center gap-7 text-sm font-serif tracking-wide">
            <a href="index.php" class="<?php echo nav_active('index.php', $current); ?>">Anasayfa</a>
            <a href="kavramlar.php" class="<?php echo nav_active('kavramlar.php', $current); ?>">Kavramlar</a>
            <a href="suhreverdi.php" class="<?php echo nav_active('suhreverdi.php', $current); ?>">Sühreverdî</a>
            <a href="eserler.php" class="<?php echo nav_active('eserler.php', $current); ?>">Eserler</a>
            <a href="karsilastirma.php" class="<?php echo nav_active('karsilastirma.php', $current); ?>">Karşılaştırma</a>
            <a href="medya.php" class="<?php echo nav_active($current === 'medya-detay.php' ? 'medya-detay.php' : 'medya.php', $current); ?>">Medya</a>
        </nav>

        <button id="menuBtn" class="md:hidden text-nur-gold text-2xl leading-none">&#9776;</button>
    </div>

    <div id="mobileMenu" class="hidden md:hidden flex-col gap-1 px-5 pb-4 font-serif">
        <a href="index.php" class="block py-2 <?php echo nav_active('index.php', $current); ?>">Anasayfa</a>
        <a href="kavramlar.php" class="block py-2 <?php echo nav_active('kavramlar.php', $current); ?>">Kavramlar</a>
        <a href="suhreverdi.php" class="block py-2 <?php echo nav_active('suhreverdi.php', $current); ?>">Sühreverdî</a>
        <a href="eserler.php" class="block py-2 <?php echo nav_active('eserler.php', $current); ?>">Eserler</a>
        <a href="karsilastirma.php" class="block py-2 <?php echo nav_active('karsilastirma.php', $current); ?>">Karşılaştırma</a>
        <a href="medya.php" class="block py-2 <?php echo nav_active($current === 'medya-detay.php' ? 'medya-detay.php' : 'medya.php', $current); ?>">Medya</a>
    </div>
</header>

<script>
    const menuBtn = document.getElementById('menuBtn');
    const mobileMenu = document.getElementById('mobileMenu');
    if (menuBtn) {
        menuBtn.addEventListener('click', () => {
            mobileMenu.classList.toggle('hidden');
            mobileMenu.classList.toggle('flex');
        });
    }
</script>
