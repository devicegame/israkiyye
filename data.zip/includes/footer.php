    </main>

    <footer class="border-t nur-border mt-10">
        <div class="max-w-5xl mx-auto px-5 md:px-8 py-10">
            <div class="nur-divider mb-8"></div>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8 text-sm text-gray-400">
                <div>
                    <h3 class="font-display text-nur-gold mb-3 tracking-wider">İŞRÂKİYYE</h3>
                    <p class="leading-relaxed">
                        Nûr ve hikmet üzerine kurulu, zevk ile keşfi akılla birleştiren
                        İşrâkî hikmet okulunun dijital bir arşividir. Bilgi, karanlığın
                        içinde parlayan bir ışıktır.
                    </p>
                </div>
                <div>
                    <h3 class="font-display text-nur-gold mb-3 tracking-wider">HIZLI BAĞLANTILAR</h3>
                    <ul class="space-y-2">
                        <li><a href="index.php" class="hover:text-nur-gold transition">Anasayfa</a></li>
                        <li><a href="kavramlar.php" class="hover:text-nur-gold transition">Kavramlar</a></li>
                        <li><a href="suhreverdi.php" class="hover:text-nur-gold transition">Şehabeddin Sühreverdî</a></li>
                        <li><a href="eserler.php" class="hover:text-nur-gold transition">Eserler &amp; Risaleler</a></li>
                        <li><a href="karsilastirma.php" class="hover:text-nur-gold transition">Karşılaştırmalı Tasnif</a></li>
                        <li><a href="medya.php" class="hover:text-nur-gold transition">Medya &amp; Kanallar</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="font-display text-nur-gold mb-3 tracking-wider">NÛR'DAN BİR SÖZ</h3>
                    <p class="italic leading-relaxed">
                        "Hikmet, karanlık bedenden sıyrılıp nûrun aslına dönmektir."
                        <br><span class="text-gray-500">- Şihâbüddîn Sühreverdî</span>
                    </p>
                </div>
            </div>
            <div class="nur-divider my-8"></div>
            <p class="text-center text-xs text-gray-500 tracking-wide">
                &copy; <?php echo date("Y"); ?> İşrâkiyye Arşivi — Tüm hakları saklıdır.
                Flat-file mimari ile, veritabanı olmaksızın, sade bir nûr ile inşa edilmiştir.
            </p>
        </div>
    </footer>
</body>
</html>
