<?php
if (!isset($site_title)) {
    $site_title = "İşrâkiyye | Nûr Felsefesi";
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $site_title; ?></title>
    <meta name="description" content="Şehabeddin Sühreverdî ve İşrâkî Hikmet Okulu üzerine kapsamlı bir kaynak.">
    <meta name="theme-color" content="#0b0f1a">

    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        'nur-gold': '#d4af37',
                        'nur-amber': '#e8c872',
                        'nur-bg': '#0b0f1a',
                        'nur-panel': '#11162380',
                    },
                    fontFamily: {
                        serif: ['"Noto Serif"', 'Georgia', 'serif'],
                        display: ['"Cinzel"', '"Noto Serif"', 'serif'],
                    }
                }
            }
        }
    </script>

    <!-- Fontlar -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;600;700&family=Noto+Serif:ital,wght@0,400;0,600;1,400&display=swap" rel="stylesheet">

    <style>
        body {
            background-color: #0b0f1a;
            background-image: radial-gradient(circle at 50% 0%, rgba(212,175,55,0.08), transparent 60%);
            color: #e5e0d8;
            font-family: 'Noto Serif', serif;
        }
        .text-glow {
            text-shadow: 0 0 18px rgba(212,175,55,0.35);
        }
        .nur-border {
            border-color: rgba(212,175,55,0.25);
        }
        .nur-card {
            background: linear-gradient(180deg, rgba(255,255,255,0.03), rgba(255,255,255,0.01));
            border: 1px solid rgba(212,175,55,0.18);
        }
        .nur-divider {
            background: linear-gradient(90deg, transparent, rgba(212,175,55,0.6), transparent);
            height: 1px;
        }
        ::selection {
            background: rgba(212,175,55,0.35);
        }
    </style>
</head>
<body class="min-h-screen antialiased">
<?php include __DIR__ . "/navbar.php"; ?>
<main class="max-w-5xl mx-auto px-5 md:px-8 pt-10 pb-24">
