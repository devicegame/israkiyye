<?php
$site_title = "Şehabeddin Sühreverdî | İşrâkiyye";
require __DIR__ . "/includes/header.php";
require __DIR__ . "/data/content.php";
?>

<section class="text-center py-10">
    <p class="uppercase tracking-[0.3em] text-xs text-nur-gold mb-3">Şeyhü'l-İşrâk</p>
    <h1 class="font-display text-3xl md:text-4xl text-nur-gold text-glow mb-4">
        <?php echo $biyografi["tam_ad"]; ?>
    </h1>
    <p class="text-gray-400">
        <?php echo $biyografi["dogum"]; ?> &mdash; <?php echo $biyografi["vefat"]; ?>
    </p>
</section>

<div class="nur-divider my-8"></div>

<section class="grid md:grid-cols-3 gap-6 mb-12">
    <div class="nur-card rounded-xl p-6 text-center">
        <p class="text-xs text-nur-gold uppercase tracking-widest mb-2">Lakap</p>
        <p class="text-gray-200"><?php echo $biyografi["lakap"]; ?></p>
    </div>
    <div class="nur-card rounded-xl p-6 text-center">
        <p class="text-xs text-nur-gold uppercase tracking-widest mb-2">Doğum</p>
        <p class="text-gray-200"><?php echo $biyografi["dogum"]; ?></p>
    </div>
    <div class="nur-card rounded-xl p-6 text-center">
        <p class="text-xs text-nur-gold uppercase tracking-widest mb-2">Vefat</p>
        <p class="text-gray-200"><?php echo $biyografi["vefat"]; ?></p>
    </div>
</section>

<section class="space-y-10">
    <article class="nur-card rounded-2xl p-8">
        <h2 class="font-display text-2xl text-nur-amber mb-4">Hayatı ve Yetişmesi</h2>
        <p class="text-gray-300 leading-relaxed mb-4">
            Şihâbüddîn Yahyâ es-Sühreverdî, yaklaşık 1154 yılında bugünkü İran'ın
            kuzeybatısındaki Sühreverd kasabasında dünyaya geldi. Erken yaşlarda
            Meraga ve İsfahan gibi dönemin önemli ilim merkezlerinde mantık, fıkıh
            ve felsefe tahsil etti. Mecdüddin el-Cîlî gibi hocalardan ders aldığı,
            aynı dönemde Fahreddin er-Râzî ile birlikte öğrenim gördüğü rivayet edilir.
        </p>
        <p class="text-gray-300 leading-relaxed">
            Gençlik yıllarında Anadolu ve Suriye'yi dolaşan Sühreverdî, tasavvufî
            çevrelerle de temas kurmuş, riyazet ve halvet uygulamalarıyla kendi
            ifadesiyle "içsel keşif" tecrübeleri yaşamıştır. Bu tecrübeler, salt akli
            istidlale dayanan Meşşâî felsefeye duyduğu güvensizliğin temelini oluşturur.
        </p>
    </article>

    <article class="nur-card rounded-2xl p-8">
        <h2 class="font-display text-2xl text-nur-amber mb-4">Felsefi Projesi: İşrâkî Hikmetin İnşası</h2>
        <p class="text-gray-300 leading-relaxed mb-4">
            Sühreverdî, kendisinden önceki felsefe tarihini iki ana damar olarak okur:
            Meşşâî (Aristocu) çizgi ve "işrâkî" ya da "zevkî" çizgi. Ona göre Hermes,
            Pisagor, Eflatun, Zerdüşt ve eski İran bilgeleri (Fehlevîyyûn) hep bu ikinci
            çizgiye mensuptur ve hakikate hem akıl hem de ruhani müşahede yoluyla ulaşmışlardır.
        </p>
        <p class="text-gray-300 leading-relaxed mb-4">
            Hikmetü'l-İşrâk adlı başyapıtında bu iki mirası birleştirmeye çalışır:
            eserin ilk bölümü sağlam bir mantık ve epistemoloji eleştirisi sunarken,
            ikinci bölüm "Nûr Metafiziği" adını verdiği özgün varlık teorisini ortaya koyar.
            Bu teoride varlık, nûr (ışık) yoğunluğuna göre derecelenir; en tepede
            kendinden var olan "Nûrü'l-Envâr" bulunur.
        </p>
        <p class="text-gray-300 leading-relaxed">
            Sühreverdî'nin sembolik risaleleri (Kırmızı Akıl, Cebrail'in Kanat Sesi,
            Kuşların Risalesi) ise aynı felsefi içeriği şiirsel ve alegorik bir dille,
            geniş kitlelere ve mürid topluluklarına ulaştırma amacı taşır.
        </p>
    </article>

    <article class="nur-card rounded-2xl p-8 border-red-900/40">
        <h2 class="font-display text-2xl text-red-400 mb-4">Trajik Sonu: "Maktûl" Lakabı</h2>
        <p class="text-gray-300 leading-relaxed mb-4">
            Sühreverdî, 1183 civarında Halep'e geldi ve burada Selahaddin Eyyûbî'nin oğlu
            Melik ez-Zâhir'in sarayında itibar gördü. Ancak cesur ve doğrudan üslubu,
            kendisini "peygamberlik benzeri bir makam"a layık görmesi ve bazı fıkıh
            âlimleriyle girdiği tartışmalar, dönemin sünni uleması arasında ciddi bir
            tepkiye yol açtı.
        </p>
        <p class="text-gray-300 leading-relaxed mb-4">
            Halep uleması, Sühreverdî'nin görüşlerini zındıklık ve ilhad ile itham eden
            fetvalar yayınladı. Bu baskılar karşısında, oğlunun bu genç filozofa duyduğu
            yakınlığı kaygıyla izleyen Selahaddin Eyyûbî, idam kararını onayladı.
        </p>
        <p class="text-gray-300 leading-relaxed">
            Şihâbüddîn Sühreverdî, 1191 yılında, henüz otuz yedi yaşındayken Halep
            kalesinde idam edildi. Bu trajik son, kendisine İslam düşünce tarihinde
            "eş-Şeyhü'l-Maktûl" (öldürülen şeyh) lakabını kazandırmış; onu, hakikat
            uğruna bedel ödeyen bir "şehid-i aşk" figürüne dönüştürmüştür.
        </p>
    </article>
</section>

<?php require __DIR__ . "/includes/footer.php"; ?>
