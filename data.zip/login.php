<?php
require_once __DIR__ . '/includes/media_lib.php';

if (current_user()) {
    redirect('dashboard.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check()) {
        flash_set('err', 'Güvenlik doğrulaması başarısız. Tekrar deneyin.');
        redirect('login.php');
    }
    if ($wait = login_locked()) {
        flash_set('err', "Çok fazla hatalı deneme. $wait saniye sonra tekrar deneyin.");
        redirect('login.php');
    }
    $username = trim((string)($_POST['username'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    $user = find_user_by_username($username);

    if ($user && password_verify($password, $user['password_hash'])) {
        login_ok();
        $_SESSION['user_id'] = (int)$user['id'];
        redirect('dashboard.php');
    }
    login_fail();
    flash_set('err', 'Kullanıcı adı veya şifre hatalı.');
    redirect('login.php');
}

$site_title = "Medya Girişi | İşrâkiyye";
require __DIR__ . '/includes/header.php';
$inputCls = 'w-full px-4 py-2.5 rounded-lg bg-white/5 border nur-border text-gray-200 focus:outline-none focus:border-nur-gold';
?>
<section class="py-10 max-w-md mx-auto">
    <p class="uppercase tracking-[0.3em] text-xs text-nur-gold mb-2 text-center">Medya</p>
    <h1 class="font-display text-3xl text-nur-gold text-glow mb-8 text-center">Kanal Girişi</h1>
    <?php flash_render(); ?>
    <div class="nur-card rounded-2xl p-8">
        <form method="post" class="space-y-4">
            <?php echo csrf_field(); ?>
            <input class="<?php echo $inputCls; ?>" name="username" placeholder="Kullanıcı adı" required autocomplete="username">
            <input class="<?php echo $inputCls; ?>" type="password" name="password" placeholder="Şifre" required autocomplete="current-password">
            <button class="w-full px-6 py-2.5 bg-nur-gold text-nur-bg font-semibold rounded-full hover:bg-nur-amber transition">Giriş Yap</button>
        </form>
    </div>
    <p class="text-xs text-gray-500 text-center mt-5">Hesaplar yalnızca site yöneticisi tarafından tanımlanır.</p>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
