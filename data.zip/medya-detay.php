<?php
require_once __DIR__ . '/includes/media_lib.php';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$channel = $id ? find_user_by_id($id) : null;

if (!$channel) {
    http_response_code(404);
    $site_title = "Kanal Bulunamadı | İşrâkiyye";
    require __DIR__ . '/includes/header.php';
    echo '<section class="text-center py-20"><h1 class="font-display text-3xl text-nur-gold mb-4">Kanal bulunamadı</h1>'
       . '<a href="medya.php" class="text-nur-amber hover:underline">&larr; Tüm kanallara dön</a></section>';
    require __DIR__ . '/includes/footer.php';
    exit;
}

$posts = posts_of_user((int)$channel['id']);   // en yeni üstte
$site_title = $channel['channel_name'] . " | Medya | İşrâkiyye";
require __DIR__ . '/includes/header.php';
?>

<a href="medya.php" class="text-sm text-nur-amber hover:underline">&larr; Tüm kanallar</a>

<section class="text-center py-10">
    <div class="flex justify-center mb-5"><?php echo avatar_html($channel, 'w-28 h-28', 'text-5xl'); ?></div>
    <h1 class="font-display text-3xl md:text-4xl text-nur-gold text-glow mb-3"><?php echo e($channel['channel_name']); ?></h1>
    <?php if (!empty($channel['bio'])): ?>
        <p class="max-w-2xl mx-auto text-gray-400 leading-relaxed"><?php echo e($channel['bio']); ?></p>
    <?php endif; ?>
    <p class="text-xs text-gray-500 mt-3"><?php echo count($posts); ?> post</p>
</section>

<div class="nur-divider my-8"></div>

<?php if (!$posts): ?>
    <p class="text-center text-gray-500 py-10">Bu kanal henüz bir şey paylaşmadı.</p>
<?php else: ?>
    <section class="space-y-10">
        <?php foreach ($posts as $p): ?>
            <article class="nur-card rounded-2xl overflow-hidden">
                <?php if (!empty($p['image_url'])): ?>
                    <img src="<?php echo e($p['image_url']); ?>" alt="<?php echo e($p['title']); ?>" loading="lazy"
                         class="w-full max-h-[28rem] object-cover">
                <?php endif; ?>
                <div class="p-8">
                    <p class="text-xs uppercase tracking-widest text-nur-gold mb-2"><?php echo e(fmt_date($p['created_at'])); ?></p>
                    <h2 class="font-display text-2xl text-nur-amber mb-4"><?php echo e($p['title']); ?></h2>
                    <div class="text-gray-300 leading-relaxed"><?php echo nl2br(e($p['content'])); ?></div>
                </div>
            </article>
        <?php endforeach; ?>
    </section>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>
