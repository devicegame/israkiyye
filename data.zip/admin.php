<?php
require_once __DIR__ . '/includes/media_lib.php';

$setupMode = !is_file(ADMIN_FILE);

/* ---------------- POST işlemleri ---------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check()) {
        flash_set('err', 'Güvenlik doğrulaması başarısız. Sayfayı yenileyip tekrar deneyin.');
        redirect('admin.php');
    }
    $action = $_POST['action'] ?? '';

    // İlk kurulum: admin hesabı oluştur
    if ($action === 'setup' && $setupMode) {
        $u = trim((string)($_POST['username'] ?? ''));
        $p = (string)($_POST['password'] ?? '');
        if (!preg_match('/^[A-Za-z0-9_.-]{3,30}$/', $u)) {
            flash_set('err', 'Kullanıcı adı 3-30 karakter olmalı (harf, rakam, _ . -).');
        } elseif (strlen($p) < 10) {
            flash_set('err', 'Admin şifresi en az 10 karakter olmalı.');
        } else {
            json_write(ADMIN_FILE, ['username' => $u, 'password_hash' => password_hash($p, PASSWORD_DEFAULT)]);
            session_regenerate_id(true);
            $_SESSION['is_admin'] = true;
            flash_set('ok', 'Admin hesabı oluşturuldu.');
        }
        redirect('admin.php');
    }

    // Admin girişi
    if ($action === 'login' && !$setupMode) {
        if ($wait = login_locked()) {
            flash_set('err', "Çok fazla hatalı deneme. $wait saniye sonra tekrar deneyin.");
            redirect('admin.php');
        }
        $admin = json_read(ADMIN_FILE);
        $u = (string)($_POST['username'] ?? '');
        $p = (string)($_POST['password'] ?? '');
        if (!empty($admin['password_hash'])
            && hash_equals((string)$admin['username'], $u)
            && password_verify($p, $admin['password_hash'])) {
            login_ok();
            $_SESSION['is_admin'] = true;
            redirect('admin.php');
        }
        login_fail();
        flash_set('err', 'Kullanıcı adı veya şifre hatalı.');
        redirect('admin.php');
    }

    // Aşağıdaki işlemler yalnızca admin içindir
    if (!is_admin()) {
        redirect('admin.php');
    }

    if ($action === 'logout') {
        unset($_SESSION['is_admin']);
        session_regenerate_id(true);
        redirect('admin.php');
    }

    if ($action === 'create_user') {
        $username = trim((string)($_POST['username'] ?? ''));
        $password = (string)($_POST['password'] ?? '');
        $channel  = trim((string)($_POST['channel_name'] ?? ''));
        $bio      = trim((string)($_POST['bio'] ?? ''));
        $err = null;

        if (!preg_match('/^[A-Za-z0-9_.-]{3,30}$/', $username)) {
            $err = 'Kullanıcı adı 3-30 karakter olmalı (harf, rakam, _ . -).';
        } elseif (strlen($password) < 8) {
            $err = 'Şifre en az 8 karakter olmalı.';
        } elseif (str_len($channel) < 2 || str_len($channel) > 60) {
            $err = 'Kanal adı 2-60 karakter arasında olmalı.';
        } elseif (str_len($bio) > 280) {
            $err = 'Kısa açıklama en fazla 280 karakter olabilir.';
        } elseif (find_user_by_username($username)) {
            $err = 'Bu kullanıcı adı zaten kullanılıyor.';
        }

        $avatar = null;
        if ($err === null) {
            $avatar = handle_image_upload($_FILES['avatar'] ?? ['error' => UPLOAD_ERR_NO_FILE], $upErr);
            if ($upErr) {
                $err = 'Avatar: ' . $upErr;
            }
        }

        if ($err !== null) {
            flash_set('err', $err);
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            json_update(USERS_FILE, function (&$users) use ($username, $hash, $channel, $bio, $avatar) {
                $users[] = [
                    'id'            => next_id($users),
                    'username'      => $username,
                    'password_hash' => $hash,
                    'channel_name'  => $channel,
                    'bio'           => $bio,
                    'avatar_url'    => $avatar ?: '',
                ];
            });
            flash_set('ok', "Medya hesabı oluşturuldu: $username");
        }
        redirect('admin.php');
    }

    if ($action === 'delete_user') {
        $id = (int)($_POST['id'] ?? 0);
        $user = find_user_by_id($id);
        if ($user) {
            // Hesabın postlarını ve görsellerini de sil
            json_update(POSTS_FILE, function (&$posts) use ($id) {
                $posts = array_values(array_filter($posts, function ($p) use ($id) {
                    if ((int)$p['user_id'] === $id) {
                        delete_upload($p['image_url'] ?? '');
                        return false;
                    }
                    return true;
                }));
            });
            json_update(USERS_FILE, function (&$users) use ($id) {
                $users = array_values(array_filter($users, fn($u) => (int)$u['id'] !== $id));
            });
            delete_upload($user['avatar_url'] ?? '');
            flash_set('ok', 'Hesap ve tüm postları silindi.');
        } else {
            flash_set('err', 'Hesap bulunamadı.');
        }
        redirect('admin.php');
    }

    if ($action === 'change_admin_password') {
        $admin = json_read(ADMIN_FILE);
        $cur = (string)($_POST['current'] ?? '');
        $new = (string)($_POST['new'] ?? '');
        if (!password_verify($cur, $admin['password_hash'] ?? '')) {
            flash_set('err', 'Mevcut şifre hatalı.');
        } elseif (strlen($new) < 10) {
            flash_set('err', 'Yeni şifre en az 10 karakter olmalı.');
        } else {
            $admin['password_hash'] = password_hash($new, PASSWORD_DEFAULT);
            json_write(ADMIN_FILE, $admin);
            flash_set('ok', 'Admin şifresi güncellendi.');
        }
        redirect('admin.php');
    }

    redirect('admin.php');
}

/* ---------------- Görünüm ---------------- */
$site_title = "Admin Paneli | İşrâkiyye";
require __DIR__ . '/includes/header.php';
$inputCls = 'w-full px-4 py-2.5 rounded-lg bg-white/5 border nur-border text-gray-200 focus:outline-none focus:border-nur-gold';
?>

<section class="py-6">
    <p class="uppercase tracking-[0.3em] text-xs text-nur-gold mb-2">Yönetim</p>
    <h1 class="font-display text-3xl text-nur-gold text-glow mb-6">Admin Paneli</h1>
    <?php flash_render(); ?>

<?php if ($setupMode): ?>
    <div class="nur-card rounded-2xl p-8 max-w-md">
        <h2 class="font-display text-xl text-nur-amber mb-2">İlk Kurulum</h2>
        <p class="text-sm text-gray-400 mb-5">Henüz admin hesabı yok. Dosyaları yükler yüklemez hesabı siz oluşturun.</p>
        <form method="post" class="space-y-4">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="action" value="setup">
            <input class="<?php echo $inputCls; ?>" name="username" placeholder="Admin kullanıcı adı" required autocomplete="username">
            <input class="<?php echo $inputCls; ?>" type="password" name="password" placeholder="Şifre (en az 10 karakter)" required autocomplete="new-password">
            <button class="px-6 py-2.5 bg-nur-gold text-nur-bg font-semibold rounded-full hover:bg-nur-amber transition">Admin Oluştur</button>
        </form>
    </div>

<?php elseif (!is_admin()): ?>
    <div class="nur-card rounded-2xl p-8 max-w-md">
        <h2 class="font-display text-xl text-nur-amber mb-5">Yönetici Girişi</h2>
        <form method="post" class="space-y-4">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="action" value="login">
            <input class="<?php echo $inputCls; ?>" name="username" placeholder="Kullanıcı adı" required autocomplete="username">
            <input class="<?php echo $inputCls; ?>" type="password" name="password" placeholder="Şifre" required autocomplete="current-password">
            <button class="px-6 py-2.5 bg-nur-gold text-nur-bg font-semibold rounded-full hover:bg-nur-amber transition">Giriş Yap</button>
        </form>
    </div>

<?php else:
    $users = get_users();
    $counts = [];
    foreach (get_posts() as $p) {
        $counts[(int)$p['user_id']] = ($counts[(int)$p['user_id']] ?? 0) + 1;
    }
?>
    <div class="flex justify-end mb-6">
        <form method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="action" value="logout">
            <button class="text-sm text-gray-400 hover:text-nur-gold transition">Çıkış Yap</button>
        </form>
    </div>

    <div class="grid md:grid-cols-2 gap-8">
        <!-- Yeni hesap -->
        <div class="nur-card rounded-2xl p-6">
            <h2 class="font-display text-xl text-nur-amber mb-4">Yeni Medya Hesabı</h2>
            <form method="post" enctype="multipart/form-data" class="space-y-3">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="create_user">
                <input class="<?php echo $inputCls; ?>" name="username" placeholder="Kullanıcı adı (giriş için)" required maxlength="30" autocomplete="off">
                <input class="<?php echo $inputCls; ?>" type="password" name="password" placeholder="Şifre (en az 8 karakter)" required autocomplete="new-password">
                <input class="<?php echo $inputCls; ?>" name="channel_name" placeholder="Kanal adı" required maxlength="60">
                <textarea class="<?php echo $inputCls; ?>" name="bio" rows="3" maxlength="280" placeholder="Kısa açıklama (en fazla 280 karakter)"></textarea>
                <label class="block text-sm text-gray-400">Avatar (isteğe bağlı, JPG/PNG/GIF/WEBP, en fazla 3 MB)
                    <input type="file" name="avatar" accept="image/jpeg,image/png,image/gif,image/webp" class="mt-1 block w-full text-sm text-gray-400">
                </label>
                <button class="px-6 py-2.5 bg-nur-gold text-nur-bg font-semibold rounded-full hover:bg-nur-amber transition">Hesabı Oluştur</button>
            </form>
        </div>

        <!-- Admin şifresi -->
        <div class="nur-card rounded-2xl p-6 self-start">
            <h2 class="font-display text-xl text-nur-amber mb-4">Admin Şifresini Değiştir</h2>
            <form method="post" class="space-y-3">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="change_admin_password">
                <input class="<?php echo $inputCls; ?>" type="password" name="current" placeholder="Mevcut şifre" required autocomplete="current-password">
                <input class="<?php echo $inputCls; ?>" type="password" name="new" placeholder="Yeni şifre (en az 10 karakter)" required autocomplete="new-password">
                <button class="px-6 py-2.5 border nur-border text-nur-gold rounded-full hover:bg-white/5 transition">Güncelle</button>
            </form>
        </div>
    </div>

    <div class="nur-divider my-10"></div>

    <h2 class="font-display text-xl text-nur-amber mb-5">Medya Hesapları (<?php echo count($users); ?>)</h2>
    <?php if (!$users): ?>
        <p class="text-gray-500">Henüz hesap yok.</p>
    <?php else: ?>
        <div class="space-y-3">
        <?php foreach ($users as $u): ?>
            <div class="nur-card rounded-xl p-4 flex items-center gap-4">
                <?php echo avatar_html($u, 'w-12 h-12', 'text-lg'); ?>
                <div class="flex-1 min-w-0">
                    <p class="text-nur-amber font-display truncate"><?php echo e($u['channel_name']); ?></p>
                    <p class="text-xs text-gray-500">@<?php echo e($u['username']); ?> · <?php echo (int)($counts[(int)$u['id']] ?? 0); ?> post</p>
                </div>
                <a href="medya-detay.php?id=<?php echo (int)$u['id']; ?>" class="text-xs text-nur-gold hover:underline">Görüntüle</a>
                <form method="post" onsubmit="return confirm('Bu hesap ve tüm postları kalıcı olarak silinecek. Emin misiniz?');">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="action" value="delete_user">
                    <input type="hidden" name="id" value="<?php echo (int)$u['id']; ?>">
                    <button class="text-xs text-red-400 hover:text-red-300 transition">Sil</button>
                </form>
            </div>
        <?php endforeach; ?>
        </div>
    <?php endif; ?>
<?php endif; ?>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
