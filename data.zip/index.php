<?php
$site_title = "İşrâkiyye | Nûr ve Hikmet Felsefesi";
require __DIR__ . "/includes/header.php";
require __DIR__ . "/data/content.php";
?>

<!-- HERO -->
<section class="text-center py-16 md:py-24">
    <p class="uppercase tracking-[0.3em] text-xs text-nur-gold mb-4">Hikmetü'l-İşrâk</p>
    <h1 class="font-display text-4xl md:text-6xl text-nur-gold text-glow leading-tight mb-6">
        Karanlıktan Nûra,<br class="hidden md:block"> Bedenden Hakikate
    </h1>
    <p class="max-w-2xl mx-auto text-gray-300 leading-relaxed text-lg">
        İşrâkiyye, Şihâbüddîn Sühreverdî'nin kurduğu; akıl ile zevki, burhan ile keşfi
        birleştiren, varlığı <span class="text-nur-amber">nûr</span> ve <span class="text-nur-amber">karanlık</span>
        ekseninde yeniden kuran bir hikmet geleneğidir.
    </p>
    <div class="mt-10 flex flex-wrap items-center justify-center gap-4">
        <a href="kavramlar.php" class="px-6 py-3 bg-nur-gold text-nur-bg font-semibold rounded-full hover:bg-nur-amber transition">
            Kavramları Keşfet
        </a>
        <a href="suhreverdi.php" class="px-6 py-3 border nur-border text-nur-gold rounded-full hover:bg-white/5 transition">
            Sühreverdî'nin Hayatı
        </a>
    </div>
</section>

<div class="nur-divider my-6"></div>

<!-- TANITIM -->
<section class="py-10 grid md:grid-cols-2 gap-10 items-center">
    <div>
        <h2 class="font-display text-2xl text-nur-gold mb-4">İşrâkî Felsefe Nedir?</h2>
        <p class="text-gray-300 leading-relaxed mb-4">
            12. yüzyılda yaşayan Şihâbüddîn Sühreverdî, dönemin hâkim felsefesi olan
            Meşşâî (Aristocu-İbn Sînâcı) geleneğin salt akıl yürütmeye dayalı yöntemini
            yetersiz bularak, bilgeliğin hem akli burhanla hem de ruhani zevk/keşif ile
            elde edilebileceğini savunmuştur.
        </p>
        <p class="text-gray-300 leading-relaxed">
            Ona göre varlık, nûr (ışık) ile karanlık arasında dereceli bir hiyerarşidir.
            Her varlık, sahip olduğu nûr miktarınca gerçek, kendinden bilinir ve değerlidir.
            Bu anlayış, antik İran hikmeti, Eflatuncu idealar öğretisi ve İslam tasavvufunu
            özgün bir sentezde buluşturur.
        </p>
    </div>
    <div class="nur-card rounded-2xl p-8">
        <h3 class="font-display text-nur-amber mb-4">Üç Temel Direk</h3>
        <ul class="space-y-4 text-gray-300">
            <li class="flex gap-3"><span class="text-nur-gold">١</span> Nûr Metafiziği — varlık = ışık yoğunluğu</li>
            <li class="flex gap-3"><span class="text-nur-gold">٢</span> Huzûrî İlim — doğrudan, aracısız bilgi</li>
            <li class="flex gap-3"><span class="text-nur-gold">٣</span> Riyazet ve Keşif — nefsin arınma yolu</li>
        </ul>
    </div>
</section>

<div class="nur-divider my-10"></div>

<!-- ÖNE ÇIKAN KAVRAMLAR -->
<section class="py-6">
    <div class="flex items-center justify-between mb-8">
        <h2 class="font-display text-2xl text-nur-gold">Öne Çıkan Kavramlar</h2>
        <a href="kavramlar.php" class="text-sm text-nur-amber hover:underline">Tümünü Gör &rarr;</a>
    </div>
    <div class="grid md:grid-cols-3 gap-6">
        <?php
        $sayac = 0;
        foreach ($kavramlar as $k):
            if ($sayac >= 3) break;
            $sayac++;
        ?>
            <div class="nur-card rounded-xl p-6 hover:border-nur-gold/60 transition">
                <h3 class="font-display text-lg text-nur-amber mb-2"><?php echo $k["baslik"]; ?></h3>
                <p class="text-sm text-gray-400 leading-relaxed"><?php echo $k["kisa"]; ?></p>
                <a href="kavramlar.php#<?php echo $k['slug']; ?>" class="inline-block mt-4 text-xs text-nur-gold hover:underline">Devamını Oku &rarr;</a>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<div class="nur-divider my-10"></div>

<!-- ÖNE ÇIKAN ESERLER / RİSALELER -->
<section class="py-6">
    <div class="flex items-center justify-between mb-8">
        <h2 class="font-display text-2xl text-nur-gold">Öne Çıkan Risaleler</h2>
        <a href="eserler.php" class="text-sm text-nur-amber hover:underline">Tümünü Gör &rarr;</a>
    </div>
    <div class="grid md:grid-cols-2 gap-6">
        <?php
        $sayac2 = 0;
        foreach ($eserler as $e):
            if ($sayac2 >= 4) break;
            $sayac2++;
        ?>
            <div class="nur-card rounded-xl p-6">
                <p class="text-xs uppercase tracking-widest text-nur-gold mb-2"><?php echo $e["tur"]; ?></p>
                <h3 class="font-display text-lg text-nur-amber mb-2"><?php echo $e["baslik"]; ?></h3>
                <p class="text-sm text-gray-400 leading-relaxed"><?php echo $e["ozet"]; ?></p>
                <a href="eserler.php#<?php echo $e['slug']; ?>" class="inline-block mt-4 text-xs text-nur-gold hover:underline">İncele &rarr;</a>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<?php require __DIR__ . "/includes/footer.php"; ?>
